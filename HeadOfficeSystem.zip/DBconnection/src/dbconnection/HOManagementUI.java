package dbconnection;

import java.util.ArrayList;

public interface HOManagementUI {
	/**
	 * 
	 * Get the not Attended 
	 * @param Q
	 * @param date
	 * @return
	 */
	public boolean getNotAttended(ArrayList<Object[]> Q,String date);
	/**
	 * 
	 * Get Client 
	 * @param Q
	 * @return
	 */
	public boolean getClient(ArrayList<Object[]> Q); 
	/**
	 * Calculate Statistics 
	 * 
	 * @param ClientsPerDay
	 * @param casetype
	 * @param Recommendations
	 * @param Allclients
	 * @param Branch
	 * @return
	 */
	public boolean CalculateStatistics(int ClientsPerDay[], int casetype[],int Recommendations[], int Allclients[], int Branch);
	/**
	 * Insert Legal Opinion 
	 * 
	 * @param Rec_LegalOp
	 * @return
	 */
	public boolean insertLegalOpinion(String Rec_LegalOp); 
	/**
	 * Insert Recommendation 
	 * 
	 * @param Rec
	 * @return
	 */
	public boolean insertRecommendation(String Rec);  
	/**
	 * 
	 * Insert Case Type 
	 * @param CaseType
	 * @return
	 */
	public boolean insertCaseType(String CaseType);

}