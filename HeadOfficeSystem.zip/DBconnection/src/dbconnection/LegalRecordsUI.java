package dbconnection;

import java.util.ArrayList;

public interface LegalRecordsUI {

	/**
	 * Update Records
	 * 
	 * @param ClientID
	 * @param Name
	 * @param Surname
	 * @param DOB
	 * @param Telephone
	 * @param Address
	 * @return
	 */
	public boolean updateRecord(int ClientID, String Name, String Surname, String DOB, String Telephone, String Address);
	
	/**
	 * Insert Client Record 
	 * 
	 * @param clientID
	 * @param Name
	 * @param Surname
	 * @param DOB
	 * @param Telephone
	 * @param Address
	 * @return
	 */
	public boolean insertClientRecord(Integer clientID, String Name, String Surname,  String DOB,
			String Telephone, String Address);

	
	
	/**
	 * Get Request 
	 * 
	 * @param Q
	 * @return
	 */
	public boolean getRequest(ArrayList<Object[]> Q);
	/**
	 * 
	 * Update status of Done 
	 * @param requestID
	 * @return
	 */
	public boolean updateDone(int requestID);
	
	
	/**
	 * Update Client Status Remove 
	 * 
	 * @param ClientID
	 * @return
	 */
	public boolean updateClientRemove(int ClientID);

	/**
	 * Update Status 
	 * 
	 * @param ClientID
	 * @return
	 */
	public boolean updateStatus(int ClientID);
	
	/**
	 * Get Client 
	 * 
	 * @param Q
	 * @return
	 */
	public boolean getClient(ArrayList<Object[]> Q);
	
	
	/**
	 * Get Appoiments 
	 * 
	 * @param Q
	 * @return
	 */
	public boolean getAppointments(ArrayList<Object[]> Q) ;
	
	/**
	 * Get all case 
	 * 
	 * @param Q
	 * @return
	 */
	public boolean getCases(ArrayList<Object[]> Q);
	/**
	 * Get the Dispute Transaction 
	 * 
	 * @param Q
	 * @return
	 */
	public boolean getDisputeTransaction(ArrayList<Object[]> Q);
	
	/**
	 * Get Dispute 
	 * 
	 * @param Q
	 * @return
	 */
	public boolean getDispute(ArrayList<Object[]> Q);
	
	//
	
	/**
	 * Check Update Record 
	 * 
	 * @param ClientID
	 * @return
	 */
	public boolean noUpdateRecord(int ClientID);
	/**
	 * 
	 * Request Decision 
	 * @param Request_ID
	 * @param decision
	 * @return
	 */
	public boolean requestDecision(int Request_ID, Boolean decision);
	/**
	 * 
	 * Get Who Needs Removed
	 * @param Q
	 * @return
	 */
	public boolean getWhoNeedsRemoved(ArrayList<Object[]> Q);

}
