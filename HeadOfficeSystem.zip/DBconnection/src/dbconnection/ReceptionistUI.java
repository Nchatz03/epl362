package dbconnection;

import java.util.ArrayList;


public interface ReceptionistUI {

	/**
	 * Inserts a new client in the database
	 * 
	 * @param Name
	 * @param Surname
	 * @param Sex
	 * @param DOB
	 * @param Telephone
	 * @param Address
	 * @param Status
	 * @return
	 */
	public boolean insertClient(String Name, String Surname, String Sex, String DOB, String Telephone, String Address,String Status);

	
	
	/**Returns all the clients from the database
	 * @param Q
	 * @return
	 */
	public boolean getClient(ArrayList<Object[]> Q);
	
	/**
	 * Search a specific client giving name and surname
	 * 
	 * @param Q
	 * @param Name
	 * @param Surname
	 * @return
	 */
	public boolean searchClient(ArrayList<Object[]> Q,String Name, String Surname);
	
	
	
	/** Insert an appointment
	 * @param ClientID
	 * @param Date
	 * @param LawyerID
	 * @param BranchID
	 * @return
	 */
	public boolean insertAppointment(int ClientID, String Date,int LawyerID,int BranchID);
	
	
	
	/**Get all appointments from database
	 * @param Q
	 * @return
	 */
	public boolean getAppointments(ArrayList<Object[]> Q);

	/**
	 * Inserts if a client went to an appointment or not
	 * @param AppointmentID
	 * @param accomplish
	 * @return
	 */
	public boolean checkIfClientWent(int AppointmentID, String accomplish);
	
	/** Insert a drop in
	 * @param ClientID
	 * @param Date
	 * @param LawyerID
	 * @param BranchID
	 * @return
	 */
	public boolean insertDropIN(int ClientID, String Date, int LawyerID, int BranchID);
	
	/**Get all the appointments that are drop in
	 * @param Q
	 * @return
	 */
	public boolean getDropIn(ArrayList<Object[]> Q);
	
	/**Get all lawyers
	 * @param Q
	 * @return
	 */
	public boolean getLawyers(ArrayList<Object[]> Q);
	
	/**Inserts a legal opinion
	 * @param Rec_LegalOp
	 * @return
	 */
	public boolean insertLegalOpinion(String Rec_LegalOp);
	
	/**Inserts a recmmendation
	 * @param Rec
	 * @return
	 */
	public boolean insertRecommendation(String Rec); 
	
	
	
	


}
