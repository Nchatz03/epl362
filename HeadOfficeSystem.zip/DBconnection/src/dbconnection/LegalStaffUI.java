package dbconnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public interface LegalStaffUI {

	/**Returns all clients
	 * @param Q
	 * @return
	 */
	public boolean getClient(ArrayList<Object[]> Q);

	/**Checks if the client have already that case
	 * @param CaseTrans
	 * @param ClientID
	 * @return
	 */
	public boolean isCaseTheSame(String CaseTrans, int ClientID);

	/**Insert a new case for a client
	 * @param CaseTrans
	 * @param ClientID
	 * @param LawyerID
	 * @return
	 */
	public boolean addNewCase(String CaseTrans, int ClientID, int LawyerID);

	/**Add an illegal client
	 * @param CaseID
	 * @return
	 */
	public boolean addIllegal(int CaseID);

	/**Add a legal client
	 * @param CaseID
	 * @return
	 */
	public boolean addLegal(int CaseID);

	/**Checks if a clients has the same recommendation
	 * @param Recommendation
	 * @param CaseID
	 * @return
	 */
	public boolean isRecommedationTheSame(String Recommendation, int CaseID);

	/**Change the recommendation of a case
	 * @param Recommedation
	 * @param CaseID
	 * @return
	 */
	public boolean changeRecommendation(String Recommedation, int CaseID);

	/**Inserts a recommendation
	 * @param Recommedation
	 * @param CaseID
	 * @return
	 */
	public boolean insertRecommendation(String Recommedation, int CaseID);

	/**
	 * Inserts a request
	 * @param ClientID
	 * @param requestName
	 * @param requestSurname
	 * @param requestAddress
	 * @param requestPhone
	 * @param requestDOB
	 * @param name
	 * @param surname
	 * @param Address
	 * @param phone
	 * @param DOB
	 * @return
	 */
	public boolean insertRequest(int ClientID, boolean requestName, boolean requestSurname, boolean requestAddress,
			boolean requestPhone, boolean requestDOB, String name, String surname, String Address, String phone,
			String DOB);

	
	/**Add a client to be removed
	 * @param ClientID
	 * @return
	 */
	public boolean addRemoveClient(int ClientID);

	/**Add a clients that needs to be updated
	 * @param ClientID
	 * @return
	 */
	public boolean needsUpdate(int ClientID);

	/**Get a client of a specific case
	 * @param CaseID
	 * @return
	 */
	public int getClients(int CaseID);

	/**Make a client illegal
	 * @param ClientID
	 * @return
	 */
	public boolean updateIllegal(int ClientID);

	/**Make a client legal
	 * @param ClientID
	 * @return
	 */
	public boolean updateLegal(int ClientID);

	/**Returns the clients that need to be updated
	 * @param Q
	 * @return
	 */
	public boolean getNeedsUpdate(ArrayList<Object[]> Q);

	/**Get all the illegal clients
	 * @param Q
	 * @return
	 */
	public boolean getIllegal(ArrayList<Object[]> Q);

	/**Add a dispute
	 * @param ClientID
	 * @param CaseTrans
	 * @param Rec_LegOp
	 * @return
	 */
	public boolean addDispute(int ClientID, int CaseTrans, String Rec_LegOp);

	/**Add a dispute of transaction
	 * @param ClientID
	 * @param CaseTrans
	 * @param Rec_LegOp
	 * @param LawyerID
	 * @return
	 */
	public boolean addDisputeTransaction(int ClientID, int CaseTrans, String Rec_LegOp, int LawyerID);

	/**Get all disputes
	 * @param Q
	 * @return
	 */
	public boolean getDispute(ArrayList<Object[]> Q);

	/**Get dispute of transactions
	 * @param Q
	 * @return
	 */
	public boolean getDisputeTransaction(ArrayList<Object[]> Q);

	/**Get all the unwilling clients
	 * @param Q
	 * @return
	 */
	public boolean getUnwilling(ArrayList<Object[]> Q);

	/**
	 * Checks if it' unwilling
	 * @param ClientID
	 * @param Rec_LegOp
	 * @return
	 */
	public boolean isUnwilling(int ClientID, String Rec_LegOp);

	/**Add an unwilling customer
	 * @param ClientID
	 * @param Rec_LegOp
	 * @return
	 */
	public boolean addUnwilling(int ClientID, String Rec_LegOp);

	/**View all recommendations
	 * @param Q
	 * @return
	 */
	public boolean viewRecommendations(ArrayList<String> Q);

	/**View all legal opinions
	 * @param Q
	 * @return
	 */
	public boolean viewLegalOpinions(ArrayList<String> Q);

	/**View all cases
	 * @param Q
	 * @return
	 */
	public boolean getCases(ArrayList<Object[]> Q);

	/**Checks if a client exist
	 * @param ClientID
	 * @return
	 */
	public boolean checkClientExist(int ClientID);

	/**Add a case to the appointment
	 * @param AppointmentID
	 * @param CaseTrans
	 * @return
	 */
	public boolean addCaseToAppointments(int AppointmentID, String CaseTrans);

	/**Get all the appointments of a specific lawyer
	 * @param LawyerID
	 * @param Q
	 * @return
	 */
	public boolean getAppointments(int LawyerID, ArrayList<Object[]> Q);

}