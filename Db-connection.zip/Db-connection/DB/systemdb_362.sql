-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2018 at 01:02 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemdb_362`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `ID` int(4) NOT NULL,
  `Client_ID` int(4) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `Lawyer_ID` int(4) NOT NULL,
  `Branch_ID` int(4) NOT NULL,
  `Accomplish` tinyint(1) DEFAULT NULL,
  `DateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`ID`, `Client_ID`, `Date`, `Lawyer_ID`, `Branch_ID`, `Accomplish`, `DateCreated`) VALUES
(1, 3, '2018-04-28', 1, 1, 1, ''),
(2, 2, '2018-04-17', 1, 1, 1, ''),
(3, 2, '05/05/2030', 1, 1, 0, '2018-04-13 05:23:55'),
(4, 2, '05/05/2030', 1, 1, NULL, '2018-04-13 05:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `ID` int(11) NOT NULL,
  `Address` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`ID`, `Address`) VALUES
(1, '12 Stasinou, lefkosia');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `ID` int(4) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Surname` varchar(15) NOT NULL,
  `Sex` char(1) NOT NULL,
  `DOB` varchar(25) NOT NULL,
  `NeedsUpdate` tinyint(1) DEFAULT NULL,
  `DropIn` varchar(25) DEFAULT NULL,
  `Telephone` varchar(25) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Status` varchar(10) DEFAULT NULL,
  `Rec_LegalOp` varchar(100) DEFAULT NULL,
  `CaseTrans` varchar(100) DEFAULT NULL,
  `Legal` tinyint(1) DEFAULT NULL,
  `ChangedRecord` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`ID`, `Name`, `Surname`, `Sex`, `DOB`, `NeedsUpdate`, `DropIn`, `Telephone`, `Address`, `Status`, `Rec_LegalOp`, `CaseTrans`, `Legal`, `ChangedRecord`) VALUES
(2, 'Nikolas', 'Chatzigiannis', 'M', '2018-04-18', 0, '2018-04-13 17:26:02', '', '', 'ACTIVE', 'Pie tsiaro', 'Tis poutan', 0, 0),
(4, 'George', 'Stavrou', 'F', '03/03/2000', 1, NULL, '123456789', 'En exei', NULL, NULL, NULL, 1, NULL),
(5, 'George', 'Stavrou', 'F', '03/03/2000', NULL, NULL, '123456789', 'En exei', 'ACTIVE', NULL, NULL, 1, NULL),
(6, 'George', 'Stavrou', 'F', '03/03/2000', NULL, NULL, '123456789', 'En exei', 'ACTIVE', NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dispute`
--

CREATE TABLE `dispute` (
  `Client_ID` int(11) NOT NULL,
  `DisputeDate` varchar(20) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dispute`
--

INSERT INTO `dispute` (`Client_ID`, `DisputeDate`, `Description`, `ID`) VALUES
(2, '05/05/2018', 'malakismenos', 1);

-- --------------------------------------------------------

--
-- Table structure for table `disputetransaction`
--

CREATE TABLE `disputetransaction` (
  `Dispute_ID` int(11) NOT NULL,
  `Client_ID` int(11) NOT NULL,
  `DisputeDate` varchar(20) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `LegalStrategy` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `disputetransaction`
--

INSERT INTO `disputetransaction` (`Dispute_ID`, `Client_ID`, `DisputeDate`, `Description`, `LegalStrategy`) VALUES
(1, 2, '05/05/2018', 'ethelen tsiaro', 'pareta');

-- --------------------------------------------------------

--
-- Table structure for table `lawyers`
--

CREATE TABLE `lawyers` (
  `ID` int(11) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Surname` varchar(15) NOT NULL,
  `Branch_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lawyers`
--

INSERT INTO `lawyers` (`ID`, `Name`, `Surname`, `Branch_ID`) VALUES
(1, 'Loukas', 'Soleas', 1);

-- --------------------------------------------------------

--
-- Table structure for table `legalstrategies`
--

CREATE TABLE `legalstrategies` (
  `LegalStrategy` varchar(100) NOT NULL,
  `SideEffects` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `legalstrategies`
--

INSERT INTO `legalstrategies` (`LegalStrategy`, `SideEffects`) VALUES
('pareta', 'na paeis cafe'),
('sinexise', 'kaliteros vathmos');

-- --------------------------------------------------------

--
-- Table structure for table `unwilling`
--

CREATE TABLE `unwilling` (
  `Client_ID` int(11) NOT NULL,
  `LegalStrategy` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `unwilling`
--

INSERT INTO `unwilling` (`Client_ID`, `LegalStrategy`) VALUES
(2, 'sinexise');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Type` varchar(15) NOT NULL,
  `Username` varchar(15) DEFAULT NULL,
  `Password` varchar(25) DEFAULT NULL,
  `Branch_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Type`, `Username`, `Password`, `Branch_ID`) VALUES
(5, 'LegalStaff', NULL, NULL, 1),
(6, 'Receptionist', 'gstavr02', '1234', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usertypes`
--

CREATE TABLE `usertypes` (
  `Type` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usertypes`
--

INSERT INTO `usertypes` (`Type`) VALUES
('LegalStaff'),
('Receptionist');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `dispute`
--
ALTER TABLE `dispute`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `disputetransaction`
--
ALTER TABLE `disputetransaction`
  ADD PRIMARY KEY (`Dispute_ID`,`Client_ID`);

--
-- Indexes for table `lawyers`
--
ALTER TABLE `lawyers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `usertypes`
--
ALTER TABLE `usertypes`
  ADD PRIMARY KEY (`Type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dispute`
--
ALTER TABLE `dispute`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lawyers`
--
ALTER TABLE `lawyers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
