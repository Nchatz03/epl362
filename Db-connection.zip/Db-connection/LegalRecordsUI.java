package epl362_project;

public interface LegalRecordsUI {

	public boolean updateRecord(int ClientID, String Name, String Surname, String DOB, String Telephone, String Address,String Sex);
}
