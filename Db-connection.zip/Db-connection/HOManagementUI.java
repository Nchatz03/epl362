package epl362_project;

import java.util.ArrayList;

public interface HOManagementUI {

	public boolean getClient(ArrayList<Object[]> Q); //ok
	public boolean CalculateStatistics(int ClientsPerDay[], int casetype[],int Recommendations[], int Allclients[], int Branch);
}

